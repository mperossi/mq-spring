package com.example.mq_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MqSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
